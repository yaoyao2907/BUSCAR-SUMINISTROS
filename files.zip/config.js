// Pega aquí los dos datos de tu proyecto de Supabase (Project Settings > API).
window.CFG = {
  url: "https://XXXX.supabase.co",
  key: "TU_CLAVE_PUBLICA_ANON"
};
